export { createAudioFeatureModule } from './module';
